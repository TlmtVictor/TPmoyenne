﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HNI_TPmoyennes
{
    // Classes fournies par HNI Institut
    public class Note
    {
        // Déclare une propriété entière 'matiere' qui représente l'identifiant ou le code d'une matière.
        // Le 'private set' signifie que cette propriété peut être lue de l'extérieur mais ne peut être modifiée que dans la classe.
        public int matiere { get; private set; }

        // Déclare une propriété flottante 'note' qui représente la note obtenue dans la matière.
        // Comme pour 'matiere', elle est accessible en lecture publique mais modifiable uniquement dans la classe.
        public float note { get; private set; }

        // Constructeur de la classe Note qui est appelé lors de la création d'un nouvel objet.
        // Il prend en paramètre un entier 'm' (la matière) et un float 'n' (la note), 
        // puis initialise les propriétés de l'objet avec ces valeurs.
        public Note(int m, float n)
        {
            matiere = m;
            note = n;
        }
    }
}
